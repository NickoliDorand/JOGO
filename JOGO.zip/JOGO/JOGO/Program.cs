﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JOGO
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int oculto=0;
            int limiteinferior = 1;
            int limitesuperior = 100;
            int vez = 1;
            int palpite=0;


            do
            {
                Console.WriteLine(" Jogador neutro, digite um valor ente 1 e 100");
                oculto = int.Parse(Console.ReadLine());


            } while (oculto <= 1 || oculto >= 100);

            Console.Clear();

            do
            {
                do
                { 
                    Console.WriteLine(" Jogador {0}, digite um valor entre {1} e {2}", vez, limiteinferior, limitesuperior);
                    palpite = int.Parse(Console.ReadLine());

                } while (palpite <= limiteinferior || palpite >= limitesuperior);

                if (palpite == oculto)
                {
                    Console.WriteLine(" Parabéns jogador {0}, você perdeu", vez);

                }
                else
                {
                    if (palpite< oculto)
                    {
                        limiteinferior = palpite;
                    }
                    else
                    {
                        limitesuperior = palpite;  
                    }

                }
                vez++;

                if(vez>2)
                {
                    vez = 1;
                }


            } while (palpite != oculto);
                       
        }

    } 
}
